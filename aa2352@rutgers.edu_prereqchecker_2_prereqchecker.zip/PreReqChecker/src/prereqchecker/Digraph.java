package prereqchecker;

import java.util.*;

public class Digraph {
    private int C;
    private int D;
    private HashMap<String, Integer> key = new HashMap<String, Integer>();
    private boolean isVal = false;
    private ArrayList<Course> connections = new ArrayList<Course>();

    // reads in input file and creates digraph
    public Digraph(String inputFile) {
        StdIn.setFile(inputFile);
        this.C = Integer.parseInt(StdIn.readString());

        for (int j = 0; j < C; j++) {
            String word = StdIn.readString();
            key.put(word, j);

            Course course = new Course(word);
            connections.add(course);
        }

        this.D = Integer.parseInt(StdIn.readString());

        for (int j = 0; j < D; j++) {
            String word = StdIn.readString();
            String prereq = StdIn.readString();
            int k = key.get(word);

            connections.get(k).add(prereq);
        }
    }

    public void getOutput(String outputFile) {
        StdOut.setFile(outputFile);

        for (int j = 0; j < C; j++) {
            connections.get(j).getOutput();
        }
    }

    public boolean readPrereqFile(String pFile) {
        StdIn.setFile(pFile);
        String crc1 = StdIn.readString();
        String crc2 = StdIn.readString();

        return !isValidPrereq(crc2, crc1);
    }

    public boolean isValidPrereq(String course, String prereq) {
        Course d = connections.get(key.get(course));
        ArrayList<String> arr = d.getConnections();
        if (arr.isEmpty())
            return false;
        for (int j = 0; j < arr.size(); ++j) {
            String curr = arr.get(j);
            if (curr.equals(prereq))
                return true;
            if (isValidPrereq(arr.get(j), prereq))
            return true;       
        }
        return false;
    }

    // for eligible #3
    public void eligibleOut(String eFile, String oFile){
        ArrayList<String> taken = setEligibleArray(eFile);
        flagMultiple(taken);
        StdOut.setFile(oFile);

        for (Course d: connections){
            if (checkEligibility(d))
            StdOut.println(d.getID());
        }
    }

    public ArrayList<String> setEligibleArray(String eFile) {
        ArrayList<String> arr = new ArrayList<String>();
        StdIn.setFile(eFile);

        int m = StdIn.readInt(); 
        for (int j = 0; j<m; j++) {
            int l = key.get(StdIn.readString());
            arr.add(connections.get(l).getID());
        }
        return arr;
    }

    public void flagMultiple(ArrayList<String> arr) {
        for (String s: arr) {
            flag(s);
        }
    }

    public void flag(String course)
    {
        Course d = connections.get(key.get(course));
        d.setFlag(true);
        ArrayList<String> arr = d.getConnections();
        if (arr.isEmpty())
            return;
            for (int j = 0; j < arr.size(); ++j) {
                flag(arr.get(j));     
            }
        return;
    }

    public boolean checkEligibility(Course d){
        ArrayList<String> arr = d.getConnections();
        if (d.getFlag()==true)
        return false;
        for (String s: arr){
            if (connections.get(key.get(s)).getFlag()==false)
            return false;
        }
        return true;
    }
    // for need to take class
    
    public void needToTakeOutput(ArrayList<String> taken, String target, String outputFile){
        flagMultiple(taken);
        flagRequirements(target);
        connections.get(key.get(target)).setRequirement(false);

        StdOut.setFile(outputFile);

        for (Course d: connections){
            if (d.getRequirement()){
                StdOut.println(d.getID());
            }
        }
    }

    public void flagRequirements(String target){
        Course d = connections.get(key.get(target));
        if(d.getFlag()==false)
        d.setRequirement(true);
        ArrayList<String> arr = d.getConnections();
        if (arr.isEmpty())
            return;
            for (int j = 0; j < arr.size(); ++j) {
                flagRequirements(arr.get(j));     
            }
        return;
    }

}

